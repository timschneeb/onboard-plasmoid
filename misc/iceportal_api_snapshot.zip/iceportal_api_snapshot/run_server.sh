#!/bin/sh
python3 -m http.server 9000
